Nonagon Presents
Tales of the Grave-Garden: A Sunless Sea Expansion Pack

1. Overview
2. Installation
3. Hints
4. Ships
5. Walkthrough
6. Credits

1. Overview


Tales of the Grave-Garden is both an expansion and a love letter to Sunless Sea, providing additional content for ports in the game that players normally have little reason to go to. Originally conceived as a sister mod to Rulers of the Salt Steppes, it rapidly expanded to include several new storylines, three recruitable officers, ten new ships, an assortment of rare and exotic weapons, and a few other surprises. This guide includes a list of changes as well as an in-depth walkthrough, but as exploration is a critical part of Sunless Sea, players are encouraged to go in blind. Are you ready for what waits?

2. Installation

Before installing, make a backup of your save file. Be warned that not all mods will play nicely together, and while adding a mod is (usually) harmless, removing one will corrupt your current save file.

Windows: Find the relevant files at User/appdata/LocalLow/Failbetter Games/Sunless Sea. Before making any changes, either manually save in-game (which will cost you your Invictus Token) or go into the Saves folder and backup autosave.json somewhere safe. Then, head to the Addons folder and copy the entire TotGG folder and all its subfolders into it.

To remove Tales of the Grave-Garden, delete the TotGG folder from the addon folder.

3. Hints

	-Three new titles are available when choosing a Past!
	-New shipyards have opened at Khan's Shadow and the Chelonate!
	-New shops have opened at Khan's Shadow, the Chelonate, the Nativity, and Grand Geode!
	-New companions can be discovered at Khan's Glory, Visage, Polythreme, and Codex!
	-New stories (some large, some small) can be found at Codex, Gaider's Mourn, Nuncio, the Chelonate, Visage, the Empire of Hands, Khan's Shadow and Polythreme!
	-Prisoners can now be rescued after capsizing certain ships!
	-Stone's Curse now actually does something!
	
4. Ships

Due to limitations of the shops, not all features of the new ships will be displayed in-game. Check here to see what the new ships can do!

Available at Khan's Shadow:

	Melicer-class merchant steamer
	A basic merchant ship to give those who prefer trading some extra hold space in the early game.
	
	-Weight: 1500
	-Hull 100
	-Quarters 14
	-Hold 55
	-Aft slot
	
	Minos-class Merchant Corvette
	A pacifist ship with no weapons. The game doesn't expect the Deck slot to be removed and keeps the previously-equipped gun available in combat, so for the full experience unequip your Deck slot before purchasing this ship. Otherwise, assume that your crew has jury-rigged something together.
	
	-Weight: 2500
	-Hull: 200
	-Quarters: 18
	-Hold 85
	-Cost 6000
	-Hearts +10
	-Pages +10
	-Iron -25
	-Fuel Efficiency +10%
	-Suppression (Engine will never explode)
	-No Deck Slot
	
	Lernaean-class frigate (alternate combat)
	A powerful combat vessel with a focus on Mirrors instead of Iron.
	-Weight: 4000
	-Hull: 500
	-Quarters: 32
	-Hold 80
	-Iron +5
	-Mirrors +15
	-Veils -10
	-Forward slot
	-Aft slot
	
Available at the Chelonate:

	Damysus-class Racing Skip
	A very light, very fast, very fragile ship.
	
	-Weight: 1000
	-Hull: 25
	-Quarters: 8
	-Hold: 40
	-Veils -5
	-Iron +5
	-Forward slot
	-Engine Power: +500
	
	Alcyon-class Gunship (built-in gun)
	A reasonably-priced hunting ship, required to wield the new most powerful cannon in the game.
	
	-Weight: 3600
	-Hull: 350
	-Quarters: 15
	-Hold: 55
	-Iron +15
	-Powerful forward gun
	-Aft slot
	-No Bridge slot
	
	Pallas-class Corpseboat
	A small ship that can infinitely heal itself.
	
	-Weight: 2500
	-Hull: 250
	-Quarters: 16
	-Hold: 60
	-Veils +10
	-Hearts -5
	-Self-Repair Ability
	-No Bridge slot
	-Aft slot
	
Hidden Ships (Spoilers!):

	Glorious Dreadnought
	A powerful, expensive competitor to the Dreadnaught. However, riding one of these for too long may result in strange dreams...
	
	-Weight: 4500
	-Hull: 500
	-Quarters: 50
	-Hold: 100
	-All Slots
	-Veils: -25
	-Mirrors: +30
	-Iron: +30
	-Pages: +10
	-Glorious Flare ability
	
	Husk of the Lôtān
	Heavy, slow, fragile.
	
	-Weight: 7000
	-Hull: 100
	-Quarters: 30
	-Hold: 50
	-Unclear Ability
	
	The Lôtān 
	A powerful warship that boosts Iron without sacrificing Veils.
	
	-Weight: 5000
	-Hull: 800
	-Quarters: 30
	-Hold: 120
	-All Slots
	-Iron +25
	-Mirrors +10
	-Veils +10
	-Engine Power +616
	-Unclear Ability
	
	Kielo-class Rowboat
	Surprisingly versetile for one so small.
	
	-Weight: 350
	-Hull: 300
	-Quarters: 20
	-Hold: 99
	-All Slots
	-Hearts +25
	-Mirrors +15
	-Pages +15
	-Veils +15
	-Rapid Heal
	
5. Walkthrough

If Tales of the Grave-Garden can be said to have an objective, it's the collection of Nonary Tokens scattered around the zee. This guide will help you find them and other goodies and tell you what you can do with them.

5a. A Gift for the Goddess

	Go to Nuncio when Something Awaits you. On the beach, you'll find a Gift for the Goddess as well as a Nonary Token.
	Boy, that was easy! I hope everything else is just as simple!

5b. Monkey's Unclear

	When constructing the Zeppelin, a new requirement has been added to the list: Weapons. You'll need to provide materials to build a cannon for the zeppelin to use: five Devilbone Dice, a Flare, and an Unread Log to serve as an instruction manual. Providing these will earn you the Monkey's Uncle, a peculiar weapon that fires sideways. This can be sold at the Iron Republic for one Nonary Token. 

5c. The Cave of the Answer

	Head to Codex. You'll need two materials to enter the Cave of the Answer: Prisoner's Honey to bribe the guard, followed by Foxfire Candles to enter. Passing through the cave, you'll be presented with three solutions without riddles. Remember these.
	
	At the bottom of the cave you'll come across the Shackled Ziren. There are several options here, but the only way to proceed is to present her with a Clay Man, who can listen to her tale without going mad. The Clay Man will direct you to the Merry Glassblower, in Khan's Shadow. If you haven't already, pay one zzoup to enter his shop and ask him about the Ziren. He'll direct you to the House of the Question.
	
	In the House of the Question, you'll have to enter the basement and solve the puzzles using the Cave's solutions: Turn left, provide wine for the fountain, and bring Storm's Attention to the mural. This will present you with a Dead Tongue among other goodies. Return this to the Glassblower along with Solacefruit and a Brilliant Soul (or provide your own soul) to revive the tongue, then return it to the Ziren. The Zirenw ill be freed, and will present you a Nonary Token as thanks.
	
	Once freed, the Ziren can act as a powerful Deck weapon with a 360-degree firing arc. She can be given to Abbey Rock or presented as a willing guest for the Fathomking. Alternately, the entire quest can be skipped by murdering her as soon as you find her, which will grant the token as well as a pot of her blood - violant ink.

5d. Overcooked Men

	Go to Polythreme, and bring sphinxstone. Have you already completed the Salt Lions quest? Bring sapphires instead. This will allow you to purchase Overcooked Men in exchange for Spider Silk.
	
	Overcooked Men can be sold at nine locations: The Isle of Cats, Khan's Glory, Demeaux Island, Mt. Palmerston, Adam's Way, The Chelonate, Shepherd Isles, The Uttershroom, and Naples, on the Surface. You can get various prices for Overcooked Men depending on the location. Returning to Polythreme with various amounts sold will net you a pot of Violant Ink at three, a Nonary Token and a Ray-Drenched Cinder at six, and an Element of Dawn at nine. If you have any extra Overcooked Men, they can be turned in to the King with a Hundred Hearts for a small amount of cash.	

5e. The Armless Unter

	Go to the Chelonate and visit the Ome of the Armless Unter. To advance her story, the Unter must be given 100 points worth of living gifts. These include Prisoners, Live Specimens, Harlot-Fry, Docile Blemmigans, Tomb-Colonists, and the Comatose Ferret. Prisoners will grant 10 points each, but increase Terror. If you manage to find it, Harlot-Fry will grant a whole 25 points. Once 100 points of gifts are reached, the Armless Unter will grant a Nonary Token.
	
	But wait, there's more! Meet up with the Armless Unter in London with an extremely expensive war party (three Doomed Monster Hunters) and she'll face a final battle with an unknowable foe. In return you'll be granted several Searing Enigmas, Captivating Treasures, and the Sliver of Platinum.

5f. The Nadir Palace

	This quest is very difficult. Only proceed if you are prepared for it.
	
	To begin the Nadir Palace quest, give five Tales of Terror to the Singing Mercenaries at Gaider's Mourn. They will invite you to the Lounge of Longing, where you can begin your preparations. You have ten actions to gather as much Power and Knowledge as possible before the assault. If you somehow manage to get your hands on an Unclear Device, donating it will help greatly.
	
	Good luck.

5g. The Reluctant Sniper

	The Reluctant Sniper can be picked up from Khan's Glory. If all you want is her Nonary Token, you can immediately turn her in to Khan's Glory or London to receive it. Otherwise, dine her with Supplies and Coffee.
	
	To advance her story, you'll need to defeat several enemies, then let the Sniper take the final shot: first a Jillyfleur, then a Bound-Shark, a Faustic Corsair, a break to visit the Chelonate, and then a Tyrant-Moth. After this, she can be taken to the Chapel of Lights to become the Unflinching Sniper, or to Polythreme to become the Dancing Technician. Returning her to Khan's Glory will grant a different reward, either a gun or an engine, depending on the route chosen. Either will also grant a Nonary Token.
	
	The Unflinching Sniper can be romanced, although it is suggested to be a somewhat unpleasant affair. The Dancing Technician can be propositioned, but she will reveal that she's already begun a romance with your bosun. Supporting the romance will earn you a Secret, while denying it will earn you Stone's Curse.

5h. The Distracted Cartographer

	The Distracted Cartographer can be picked up at Visage. Dine him with supplies to learn his story. To find his treasure, take him on a round trip of the zee, from Irem to Whither to London to Grand Geode to Kingeater's Castle and back to Irem, dropping off Stygian Ivory and a Wakeful Idol at all four corners of the map. Finally, return to Visage to earn an array of goodies, including a Nonary Token. You can kill the Cartographer to double your haul, but this will increase Terror.

5i. The Ordinary Human Male

	The Ordinary Human Male can be picked up in Polythreme when Something Awaits You. Dine him with Supplies to learn his story. He wants a tattoo from the Wan Sculptor, who must be freed by whatever means you choose from Wisdom. Once she has fulfulled his request, she can be brought to Polythreme to earn a Nonary Token. Well, that was easy enough.
	
	But wait, there's more! The Ordinary Human Male next requests to be lowered into Mt. Palmerston, which can be done in exchange for an Extraordinary Implication. After that, he'll reveal his great secret, and can be either kicked off the ship or kept, in which case he will transform into the Extraordinary Human Male. Here begins his second quest...
	
	Dining the Extraordinary Human Male with Souls will begin a new quest for the Lôtān, an ancient warship. Heading back to Mt. Palmerston with a Star-Shell (one can be found on completing the Distracted Cartographer's quest) will unlock the Husk of the Lôtān, a somewhat fragile and underwhelming ship. Take this to the Iron Republic and then to Kingeater's Castle. Here the Lôtān can be revived either with 20,000 echoes, by sacrificing 10 crew, or for free if your Terror is over 90.

5j. The Final Reward

	In London, you can Walk a Terrace Path to discover the Grave-Garden. Feed Nonary Tokens to the Spiralling Flower to gain Favours. At three or more Favours, the flower can be plucked. Should you collect all nine tokens, your Hearts will also increase by nine when plucking the flower.
	
	Here it is possible to obtain multiple Searing Enigmas, a Weapon Like None Other, a Book Like None Other, and a Ship Like None Other. It is also possible to gain free Tomeberries as a gift for the Fathomking. After each gift is purchased, future captains may purchase them again much more cheaply. If you purchase all three rewards, something new may happen...

6. Credits

Sunless Sea belongs to Failbetter Games Ltd.
This mod was inspired by Machallan's Rulers of the Salt Steppe mod and was made possible by jtq's Clockwork Oracle modding tools. You should check out their work.